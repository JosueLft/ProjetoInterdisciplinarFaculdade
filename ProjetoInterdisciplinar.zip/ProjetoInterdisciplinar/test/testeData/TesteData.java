package testeData;

import data.Data;

public class TesteData {
    
    public static void main(String[] args) {
        Data d = new Data();
        System.out.println(d.gerarData());
    }
}
